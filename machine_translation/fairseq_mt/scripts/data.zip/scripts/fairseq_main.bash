# cd parallel_corpus_preprocess

# uv run --active python training_data_creation.py
# ls

# cd ..
# cd unigram_preprocess

# ./unigram_conversion.bash

# cd ..


## PIVOT
# cd train

# ./train_src_pivot_dest.bash ceb eng tgl

# cd ..

# ./fairseq_evaluate.bash

## Augmentation

