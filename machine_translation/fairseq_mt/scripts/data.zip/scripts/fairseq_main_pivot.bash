# PIVOT
cd train

./train_src_pivot_dest.bash ceb eng tgl

cd ..

./fairseq_evaluate.bash

# Augmentation
